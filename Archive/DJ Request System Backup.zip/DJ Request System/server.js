const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

const PORT = 3000;
const DB_PATH = path.join(__dirname, 'dj_requests.db');

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Database connection
const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error('Database connection error:', err);
  } else {
    console.log('✅ Connected to SQLite database');
  }
});

// Socket.IO connection
io.on('connection', (socket) => {
  console.log('🔌 Client connected');
  
  socket.on('disconnect', () => {
    console.log('🔌 Client disconnected');
  });
});

// Emit queue updates
function emitQueueUpdate() {
  db.all('SELECT * FROM queue WHERE played = 0 ORDER BY requested_at ASC', [], (err, rows) => {
    if (!err) {
      io.emit('queueUpdate', rows);
    }
  });
}

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    message: 'DJ Request System is running!',
    timestamp: new Date().toISOString()
  });
});

// Get queue - FIX: Properly select artist field
app.get('/api/queue', (req, res) => {
  db.all(
    `SELECT 
      id, 
      song_id, 
      title, 
      artist,  
      requested_at, 
      played,
      requester_name
    FROM queue 
    WHERE played = 0 
    ORDER BY requested_at ASC`,
    [],
    (err, rows) => {
      if (err) {
        console.error('Queue fetch error:', err);
        return res.status(500).json({ error: 'Failed to fetch queue' });
      }
      
      // Debug: Log first song to verify artist field
      if (rows.length > 0) {
        console.log('📋 First queue item:', {
          title: rows[0].title,
          artist: rows[0].artist
        });
      }
      
      res.json({ queue: rows });
    }
  );
});

// Get current playing status - ENHANCED: Include automix info
app.get('/api/status', async (req, res) => {
  try {
    // Get player status from auto_player.py
    const playerResponse = await fetch('http://localhost:8888/status');
    const playerData = await playerResponse.json();
    
    // Get queue from database
    const queueData = await new Promise((resolve, reject) => {
      db.all(
        'SELECT id, song_id, title, artist, requested_at FROM queue WHERE played = 0 ORDER BY requested_at ASC LIMIT 10',
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
    
    res.json({
      currentSong: playerData.current_song,
      isPlaying: playerData.is_playing,
      isPaused: playerData.is_paused,
      isAutoPlaylist: playerData.is_auto_playlist,
      volume: playerData.volume,
      position: playerData.position,
      duration: playerData.duration,
      queue: queueData
    });
  } catch (error) {
    console.error('Status fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch status' });
  }
});

// Search songs
app.get('/api/search', async (req, res) => {
  const { q } = req.query;
  
  if (!q || q.trim().length < 2) {
    return res.json({ songs: [] });
  }
  
  try {
    // Call Python music-api search
    const response = await fetch(`http://localhost:8888/search?q=${encodeURIComponent(q)}`);
    const data = await response.json();
    
    res.json({ songs: data.songs || [] });
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({ error: 'Search failed' });
  }
});

// Request a song - FIX: Ensure artist is properly saved
app.post('/api/request', (req, res) => {
  const { song, requesterName } = req.body;
  
  if (!song || !song.id || !song.title) {
    return res.status(400).json({ error: 'Invalid song data' });
  }
  
  // Ensure artist has a value
  const artist = song.artist || 'Unknown Artist';
  
  console.log('🎵 Song request:', {
    title: song.title,
    artist: artist,
    requester: requesterName || 'Anonymous'
  });
  
  db.run(
    `INSERT INTO queue (song_id, title, artist, requester_name, requested_at, played) 
     VALUES (?, ?, ?, ?, datetime('now'), 0)`,
    [song.id, song.title, artist, requesterName || 'Anonymous'],
    function(err) {
      if (err) {
        console.error('Request insert error:', err);
        return res.status(500).json({ error: 'Failed to add song to queue' });
      }
      
      console.log(`✅ Song added to queue (ID: ${this.lastID})`);
      emitQueueUpdate();
      res.json({ 
        success: true, 
        queueId: this.lastID,
        message: 'Song added to queue!' 
      });
    }
  );
});

// Get user's request count
app.get('/api/user-requests', (req, res) => {
  const { name } = req.query;
  
  if (!name) {
    return res.json({ count: 0 });
  }
  
  db.get(
    'SELECT COUNT(*) as count FROM queue WHERE requester_name = ? AND played = 0',
    [name],
    (err, row) => {
      if (err) {
        console.error('User request count error:', err);
        return res.status(500).json({ error: 'Failed to fetch user requests' });
      }
      res.json({ count: row.count });
    }
  );
});

// Get recently played songs
app.get('/api/recently-played', (req, res) => {
  db.all(
    'SELECT song_id, title, artist FROM recently_played ORDER BY played_at DESC LIMIT 50',
    [],
    (err, rows) => {
      if (err) {
        console.error('Recently played fetch error:', err);
        return res.status(500).json({ error: 'Failed to fetch recently played' });
      }
      res.json({ songs: rows });
    }
  );
});

// Get settings
app.get('/api/settings', (req, res) => {
  db.get('SELECT * FROM settings WHERE id = 1', [], (err, row) => {
    if (err) {
      console.error('Settings fetch error:', err);
      return res.status(500).json({ error: 'Failed to fetch settings' });
    }
    
    if (!row) {
      // Return default settings if none exist
      return res.json({
        theme: 'general',
        welcome_title: 'DJ Song Requests',
        welcome_subtitle: 'Request your favorite songs!',
        colors: {
          primary: '#8b5cf6',
          secondary: '#ec4899',
          background: '#1a1625'
        },
        explicit_allowed: true
      });
    }
    
    // Parse JSON fields
    const settings = {
      ...row,
      colors: typeof row.colors === 'string' ? JSON.parse(row.colors) : row.colors
    };
    
    res.json(settings);
  });
});

// Update settings
app.post('/api/settings', (req, res) => {
  const { theme, welcomeTitle, welcomeSubtitle, colors, explicitAllowed } = req.body;
  
  const colorsJson = JSON.stringify(colors);
  
  db.run(
    `INSERT OR REPLACE INTO settings (id, theme, welcome_title, welcome_subtitle, colors, explicit_allowed)
     VALUES (1, ?, ?, ?, ?, ?)`,
    [theme, welcomeTitle, welcomeSubtitle, colorsJson, explicitAllowed ? 1 : 0],
    (err) => {
      if (err) {
        console.error('Settings update error:', err);
        return res.status(500).json({ error: 'Failed to update settings' });
      }
      
      console.log('✅ Settings updated');
      io.emit('settingsUpdate', { theme, welcomeTitle, welcomeSubtitle, colors, explicitAllowed });
      res.json({ success: true });
    }
  );
});

// Clear queue
app.delete('/api/queue/clear', (req, res) => {
  db.run('DELETE FROM queue WHERE played = 0', function(err) {
    if (err) {
      console.error('Queue clear error:', err);
      return res.status(500).json({ error: 'Failed to clear queue' });
    }
    
    console.log(`🗑️ Cleared ${this.changes} songs from queue`);
    emitQueueUpdate();
    res.json({ success: true, cleared: this.changes });
  });
});

// Start server
server.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔════════════════════════════════════════╗
║   🎵 DJ Request System Backend 🎵     ║
╠════════════════════════════════════════╣
║  Server running on port ${PORT}         ║
║  http://localhost:${PORT}               ║
║                                        ║
║  Access from network:                  ║
║  http://YOUR_IP:${PORT}                 ║
╚════════════════════════════════════════╝
  `);
});
